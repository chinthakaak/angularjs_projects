var user = require('./user');
var u = new user('Pankaj', 'pankaj_barbate@persistent.co.in');
console.log('Result data ==>'+u.getEmail());